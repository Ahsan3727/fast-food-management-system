# FastFood — Design System & Design-Developer Guide

**Repository:** `Ahsan3727/fast-food-management-system`
**Analyzed commit:** `51785e2` (`main`) — the Graphify index was built 2026-10-20 22:04 UTC; the repo may have moved since.
**Written:** 21 October 2026
**Sources:** Graphify code graph (1,167 nodes / 1,780 edges) + `HONEST_OVERVIEW_1.md`

---

## How to read this document

> **Important limitation.** Graphify indexes TypeScript/TSX code, **not `.css` files**. I read the full JSX, inline styles, class names, and CSS-variable *names* of every screen. I could **not** read the stylesheet bodies (`index.css`, `*.module.css`), so most token *values* (exact `--bg`, `--surface`, spacing scale, font sizes in CSS Modules) are not confirmed. Where that matters, it is marked.

| Mark | Meaning |
|---|---|
| ✅ | Read directly from source code |
| 🔶 | Inferred from code (reasonable, but confirm) |
| ❓ | Not visible through the graph — check the file named |

Document structure:

- **Part A — Design documentation** (A1–A13): what the three apps look like and how they behave.
- **Part B — Coding instructions** (B1–B9): rules, recipes, and templates for other design developers.

---
---

# PART A — DESIGN DOCUMENTATION

## A1. Product at a glance

One restaurant, Cash-on-Delivery, three front-ends sharing one NestJS API.

| | **Customer app** | **Rider app** | **Admin panel** |
|---|---|---|---|
| Path | `apps/customer` | `apps/rider` | `apps/admin` |
| Users | Hungry customers | Delivery riders | Owner / staff |
| Device | Android (Capacitor) + browser ✅ | Android (Capacitor) + browser ✅ | Desktop browser 🔶 |
| Screens | 12 (2 public, 10 private) ✅ | 5 (1 public, 4 private) ✅ | 7 (login + 6 pages) ✅ |
| Navigation | Bottom tab bar on top-level tabs; back arrow `←` on sub-screens ✅ | Single dashboard hub + back arrow ✅ | Fixed left sidebar + top header ✅ |
| Theme | Warm / light-leaning 🔶 (pastel fallbacks) | Same family as customer 🔶 | **Dark** ✅ (dark chart tooltips, `#1f2937` surfaces) |
| Styling method | CSS Modules + a few global classes ✅ | CSS Modules + a few global classes ✅ | Global utility classes + **heavy inline styles** ✅ |
| Realtime | Rider location on map | Delivery requests, GPS emit | `order:new` toast |

---

## A2. UI technology stack

| Concern | Choice | Status |
|---|---|---|
| Framework | React + Vite + TypeScript | ✅ (from overview) |
| Routing | `react-router-dom` (`Routes`, `Route`, `Navigate`, `useNavigate`, `useParams`, `useSearchParams`) | ✅ |
| Server state | TanStack-style React Query (`useQuery`, `useMutation`, `useQueryClient`) | ✅ usage / ❓ version |
| Client state | **Zustand ^5** (`useAuthStore`, `useCartStore`, `useRiderAuthStore`, `useAdminStore`) | ✅ |
| Forms | `react-hook-form` (customer, rider login, admin menu form); plain `useState` on admin login | ✅ |
| Toasts | **react-hot-toast ^2.4.1** in all three apps | ✅ |
| Maps | Leaflet + react-leaflet, OpenStreetMap tiles, emoji `L.divIcon` markers | ✅ |
| Charts | Recharts (admin only): `AreaChart`, `PieChart`, `BarChart` | ✅ |
| Realtime | `socket.io-client`, `transports: ['websocket']`, JWT in `auth.token` | ✅ |
| IDs | `uuid` v4 (idempotency key on checkout) | ✅ |
| Native shell | Capacitor 8: `app`, `android`, `browser`, `core`, `cli`, `haptics`, `network`, `status-bar`, `geolocation`, `splash-screen` | ✅ installed / ❓ which are actually used |
| Font | **Inter** (set inline in admin: `fontFamily: 'Inter, sans-serif'`) | ✅ admin / ❓ customer & rider |
| Money / dates | `@fastfood/utils` → `formatMoneyCompact`, `formatDateTime`, `timeAgo` | ✅ |
| Shared enums | `@fastfood/shared-types` → `OrderStatus`, `PaymentStatus`, `RoleType`, `SocketEvents` | ✅ |

---

## A3. Design foundations

### A3.1 Brand & voice ✅

- **Name:** FastFood. **Logo:** the 🍔 emoji (customer, admin); 🏍️ for the rider portal.
- **Taglines:** Customer login "Fresh, fast, and delivered" · Signup "Create your account" · Rider "Rider Portal — FastFood Delivery Partner" · Admin "Admin Panel — Staff Access Only".
- **Voice:** friendly, short, casual, emoji-assisted. Examples: "Hello, Ahsan 👋", "What are you craving today?", "🎉 Free", "Rider accepted your order!".
- **Locale:** English only. Pakistan context: `Rs.` currency, `+92` phone placeholders, `en-PK` date formatting, default map centre Lahore (`31.5204, 74.3587`).

### A3.2 Colour

**Values confirmed in TSX:**

| Role | Value | Where seen |
|---|---|---|
| Brand / primary orange | `#f97316` | Admin chart stroke & gradient; new-order toast `rgba(249,115,22,0.9)` |
| Dark surface (tooltip) | `#1f2937` | Recharts tooltips |
| Dark border / grid | `#374151` | Chart grid, tooltip border |
| Light text on dark | `#f9fafb` | Tooltip text |
| Muted text on dark | `#9ca3af` | Chart axes/ticks, legend |
| Pastel orange | `#fed7aa` | **Default** item-card/hero background (`item.color ?? '#fed7aa'`); "Fresh today" promo |
| Pastel yellow | `#fde68a` | "Hot deals" promo |
| Pastel pink | `#fce7f3` | "New arrivals" promo |
| Danger tint | `rgba(239,68,68,0.15)` bg + `var(--danger)` text | "SUSPENDED" chip |

**Chart palette** (`COLORS` in `AnalyticsPage.tsx`, used in this order for the status donut):
`#f97316` orange · `#3b82f6` blue · `#22c55e` green · `#f59e0b` amber · `#a78bfa` violet · `#ec4899` pink.

**CSS variables in use** (names ✅ — **values ❓ in `index.css`**):

| Token | Observed usage |
|---|---|
| `--bg` | Page background (admin login) |
| `--surface` | Cards, forms, inactive pills |
| `--border` | Card/table/pill borders |
| `--text-muted` | Secondary text, empty states |
| `--primary` | Active pills/tabs, avatars, brand text, `text-primary` |
| `--success` | Free delivery, online count, Settle/Restore |
| `--warning` | "Needs attention", unsettled cash > 0 |
| `--danger` | Cancel rate, SUSPENDED chip |
| `--info` | Customer avatar background |

**Semantic colour rules the code already follows:**
green = good/complete/online/free · amber = needs attention/money owed · red = cancel/suspend/failure · orange = brand, active selection, primary CTA · blue = neutral/info.

> 🔶 The brand orange used by `--primary` is very likely `#f97316` (matches charts and toasts) but confirm in `index.css`.

### A3.3 Typography

- **Family:** Inter ✅ (admin, inline). Customer/rider: ❓ check `index.css`.
- **Admin inline sizes seen:** 10, 11, 12, 13, 14, 15, 20, 22, 28 px; logo emoji 64 px.
- **Weights seen:** 600 (labels/pills), 700 (headings, emphasis), 800 (stat values, avatar initials).
- **Hierarchy pattern:** `h1.page-title` per page → `.card-title` per card → 13 px muted body → 11–12 px meta.
- **Emoji sizes:** 22 (bottom nav), 24 (admin table), 28/32 (map markers), 40 (category cards), 64 (login logo).
- Customer/rider sizes live inside CSS Modules → ❓.

### A3.4 Spacing, shape, elevation

From admin inline styles (✅):

- **Radii:** 4 (chips), 8 (tooltips, segmented control), 16 (login card, skeleton), 20 (filter pills), 50 % (avatars: 32 px header, 36 px tables).
- **Paddings seen:** 6·14, 7·16, 10·20, 12·0, 24, 28, 40 (empty-state rows).
- **Gaps:** 6, 10, 12, 16. **Margins:** 16, 20, 24, 40.
- The scale is *almost* 4/8-pt but not strict (6, 7, 10, 28 appear). See B4 for the proposed tidy-up.
- **Elevation:** no shadows visible in TSX; separation is by 1 px `var(--border)` lines ❓ (check CSS for shadows).

### A3.5 Iconography ✅

**There is no icon library. All icons are emoji.** This is consistent but has rendering/accessibility trade-offs (see A12).

| Emoji | Meaning | Emoji | Meaning |
|---|---|---|---|
| 🍔 | Brand, default food | 🗺️ | Track order |
| 🛒 | Cart | 🔴 | "Active orders" label |
| 🔍 | Search | 🎉 | Success / free delivery / delivered |
| 📦 | Orders / "Ready" / empty orders | ✅ / ❌ | Accept / reject, restore |
| 📍 | Address / landmark | 💰 | Earnings / settle cash |
| ⚙️ / ❓ | Settings / help | 🚫 | Suspend |
| 🏍️ | Rider | 🟢 / 🔴 | Item available / unavailable |
| 🏠 | Customer drop point | 📋 | "Order placed" step |
| 🏪 | Restaurant pickup | 👨‍🍳 | Prepare |
| 📊 🧾 🍔 🏍️ 👥 📈 | Admin: Dashboard, Orders, Menu, Riders, Customers, Analytics | 🔔 / 🛵 | New order / new delivery request |

### A3.6 Imagery ✅

Every menu item has **either** an `image` URL (Cloudinary, uploaded via `POST /uploads/image`) **or** an `emoji`, on a coloured tile (`item.color ?? '#fed7aa'`). Always design both states. The product-detail hero uses the same tile at large scale.

### A3.7 Motion & feedback

- `.skeleton` global class = loading placeholder (shimmer ❓ confirm in CSS).
- Toasts for every mutation result (react-hot-toast).
- Rider delivery request: **30-second countdown** then auto-decline.
- No page transitions or animations visible in TSX ❓.

---

## A4. Global class vocabulary

These classes are used in TSX but defined in global CSS ❓ (read their bodies in `apps/*/src/index.css`).

### Customer & Rider
`btn-primary` · `input` · `label` · `error-text` · `skeleton` · `bottom-nav` · `bottom-nav-item` (+ `active`) · `status-badge` + `status-{status}`

### Admin
| Group | Classes |
|---|---|
| Shell | `admin-layout`, `admin-sidebar`, `sidebar-brand`, `sidebar-brand-icon`, `sidebar-brand-name`, `sidebar-brand-sub`, `sidebar-nav`, `nav-item` (+`active`), `nav-icon`, `sidebar-bottom`, `admin-main`, `admin-header`, `admin-content` |
| Layout | `page-title`, `grid-2`, `stat-grid`, `flex-between`, `flex-gap`, `mt-16`, `table-wrap` |
| Cards & stats | `card`, `card-title`, `stat-card`, `stat-label`, `stat-value`, `stat-delta`, `delta-up` |
| Buttons | `btn`, `btn-primary`, `btn-ghost`, `btn-success`, `btn-danger`, `btn-sm` |
| Badges | `badge`, `badge-{status}`, `badge-online`, `badge-offline` |
| Forms | `input`, `input-group`, `label` |
| Text | `text-primary`, `text-muted`, `text-success`, `text-danger`, `font-bold` |

> ⚠️ **Two parallel badge systems:** customer uses `status-badge status-placed`; admin uses `badge badge-placed`. Same concept, different names.

---

## A5. Component catalogue

Most "components" are **file-local functions**, not shared. Only three are truly reusable.

| Component | App | File | Props | Notes |
|---|---|---|---|---|
| `BottomNav` | Customer | `components/BottomNav.tsx` | `{ active }` | Emoji (22 px) over label; `active` values seen: `home`, `menu`, `orders`, `profile` 🔶 |
| `Sidebar` | Admin | `components/Sidebar.tsx` | `{ currentPath }` | Brand block, `NAV` array, Sign Out pinned at bottom |
| `AdminLayout` | Admin | `App.tsx` (local) | `{ children }` | Sidebar + header (page title with emoji, avatar initial, name) + content; owns the `order:new` socket |
| `MenuItemCard` | Customer | `HomeScreen.tsx` (local) | `{ item, onAdd }` | Tile + name + price + round `+`; whole card navigates, `+` uses `stopPropagation` |
| `CategoryChip` | Customer | `HomeScreen.tsx` (local) | `{ name, icon, onClick }` | Emoji + label chip |
| `OrderCard` | Customer | `OrdersScreen.tsx` (local) | `{ order, navigate }` | `#number`, `timeAgo`, status badge, item count, total; active cards highlighted + "🗺️ Track Order" button |
| `PrivateRoute` / `PublicRoute` | Customer | `App.tsx` | children | Auth guards (`Private` / `Public` in rider, `Private` in admin) |
| Map icons | Customer, Rider | `TrackOrderScreen`, `OrderAssignedScreen` | — | `L.divIcon` with emoji HTML (🏠 28 px, 🏍️ 32 px, 🏪 28 px) |

---

## A6. Customer app — screen-by-screen

### Route map ✅

| Route | Screen | Guard | BottomNav? |
|---|---|---|---|
| `/login` | LoginScreen | Public | No |
| `/signup` | SignupScreen | Public | No |
| `/` | HomeScreen | Private | ✅ `home` |
| `/menu` | MenuScreen | Private | ✅ `menu` |
| `/menu/:id` | ProductDetailScreen | Private | No |
| `/search` | SearchScreen | Private | ✅ `menu` |
| `/cart` | CartScreen | Private | No |
| `/checkout` | CheckoutScreen | Private | No |
| `/orders` | OrdersScreen | Private | ✅ `orders` |
| `/orders/:id` | OrderDetailScreen | Private | No |
| `/orders/:id/track` | TrackOrderScreen | Private | No |
| `/profile` | ProfileScreen | Private | ✅ `profile` |
| `*` | → redirect `/` | — | — |

**Pattern:** bottom nav only on the four top-level tabs; every task/detail screen replaces it with a `←` back button in the header.

### 1. Login / Signup
- **Layout:** hero (🍔 logo, "FastFood", tagline) on top, white **card** below with title ("Welcome back" / "Get started"), form, footer link.
- **Login fields:** Phone or Email (placeholder `+92300xxxxxxx or you@email.com`), Password. **Signup fields:** Full Name, Phone Number, Email (optional), Password ("Min 8 characters"), Confirm Password.
- **Validation:** inline `error-text` under field ("Required", "Min 6 chars", "Min 2 chars", "Invalid phone", "Passwords do not match") + toast on API failure.
- **States:** button text switches to "Signing in…" / "Creating account…" and is disabled while loading.
- ⚠️ Login enforces min 6 chars, signup min 8 — inconsistent.

### 2. Home
Top → bottom:
1. **Header:** "Hello, {firstName} 👋" / "What are you craving today?" + 🛒 button with count badge.
2. **Search bar:** a *button* (not an input) that opens `/search`; placeholder "Search food, burgers, pizza…".
3. **Promo row:** 3 hard-coded pastel cards ("Fresh today — Up to 30% off" 🥗, "Hot deals — Burgers from Rs. 350" 🍔, "New arrivals — Desserts & more" 🍰).
4. **Categories:** section title + "See all →", horizontal chips; **fallback** to Burgers/Pizza/Drinks/Desserts when API returns none.
5. **🔥 Popular:** grid of up to 12 `MenuItemCard`s; **6 skeleton cards** while loading.
6. **Sticky cart bar** (only when cart non-empty): `{n} items · View Cart · {total}`.
7. `BottomNav active="home"`.

### 3. Menu
Header (`←`, "Menu") → horizontal **filter pills** ("All" + categories; active pill styled) → vertical list of rows (tile, name, description, price, round `+`) → 4 skeleton rows while loading → BottomNav.

### 4. Search
Header: `←`, **autofocus input**, clear `✕` when text present. Hint states: "Type at least 2 characters to search" → "Searching…" → results (emoji, name, price) → `No results for "{q}"`.

### 5. Product detail
- **Hero:** coloured tile with big emoji/image and a floating `←`.
- **Content:** name, description, **Size** option buttons (always includes "Regular" at base price), **Add-ons** (multi-select, shows `+price`), **Quantity** stepper (− / value / +, min 1), **Add to cart** button.
- On add: toast "`{name}` added to cart 🛒" then `navigate(-1)`.
- Option buttons: `option` / `optionActive` (two-line: label + price).

### 6. Cart
- **Empty:** big 🛒, "Your cart is empty", `btn-primary` "Browse Menu" (max-width 200).
- **Header:** `←`, "Cart ({n})", "Clear" (uses native `confirm()`).
- **Rows:** emoji tile, name, size, add-ons list, line price, qty stepper.
- **Summary:** Subtotal · Delivery (`🎉 Free` in `--success` green when ≥ Rs 1,000, else Rs 100) · hint "Add Rs X more for free delivery" · **Total (est.)** · note "* Final price calculated at checkout by server".
- **Footer:** "Proceed to Checkout".

### 7. Checkout
Form with 3 sections: **Order Summary** (rows + "Total (est.)" + "Server will validate exact price") → **Delivery Address** (3-row textarea min 10 chars, optional Landmark, **Latitude/Longitude number inputs**, hint "📍 Coordinates auto-filled — or enter your location") → **Payment** (COD option card; remaining JSX ❓ truncated in graph). Submit creates the order with an `idempotency-key` header, toast "Order #… placed!", then replaces route with `/orders/:id`. Empty cart redirects to `/cart`.
⚠️ Coordinates are **hard-coded to Lahore centre**, not read from GPS (see A12).

### 8. Orders list
Header "My Orders" → groups **"🔴 Active Orders"** then **"Past Orders"** → `OrderCard`s. Empty: 📦 "No orders yet" + "Order Now". 3 skeletons while loading. Polls every 10 s.

### 9. Order detail
- Header: `←`, "Order #{number}", formatted date/time.
- **Status tracker:** horizontal steps; each step = dot (shows its icon when done), label, connector line. States: done / active / line-done. First step is `PLACED — "Order Placed" 📋`; remaining steps ❓ in `STATUS_STEPS`.
- **Cancelled/Rejected/Failed:** replaces tracker with a red banner "❌ Order {status}" + reason.
- Sections: **Items** (name × qty, size, line price, total) · **Delivery Address** (+ 📍 landmark).
- **Actions:** "🗺️ Track Order" (active orders) · "Cancel Order" (only while `PLACED`, uses native `prompt()` for reason). Polls every 8 s.

### 10. Track order
- Header with live status line: `🏍️ Rider on the way!` (PICKED_UP) · `🔔 Rider heading to restaurant` (RIDER_ASSIGNED) · `🎉 Delivered!` · otherwise the **raw status string**.
- **Map** (full-width, zoom 14, zoom control hidden, OSM tiles + attribution): 🏠 home marker; 🏍️ rider marker appears when a location event arrives.
- **OTP card** (only at `PICKED_UP`): label "Show this code to the rider at delivery", large code, warning "Do not share with anyone else".
- **Waiting card** (RIDER_ASSIGNED, no GPS yet): "🏍️ Rider accepted your order! Live tracking starts when they pick up."

### 11. Profile
Avatar (first initial) + name + phone/email → list rows with chevron `›`: 📦 My Orders (works) · 📍 Saved Addresses · ⚙️ Settings · ❓ Help & Support (**last three only show a "coming soon" toast**) → "Sign Out" → BottomNav `profile`.

---

## A7. Rider app — screen-by-screen

### Route map ✅
| Route | Screen | Guard |
|---|---|---|
| `/login` | LoginScreen | Public |
| `/` | DashboardScreen | Private |
| `/order/:id` | OrderAssignedScreen | Private |
| `/earnings` | EarningsScreen | Private |
| `/profile` | ProfileScreen | Private |

### Login
Hero (🏍️, "Rider Portal", "FastFood Delivery Partner") + card form (Phone or Email, Password, "Sign In"). After login it **checks `role === 'rider'`**, otherwise toast "Not a rider account".

### Dashboard (hub)
- **Header:** "Hi, {firstName} 🏍️" / "Rider Dashboard" / "Sign Out".
- **Online card:** status dot (`dotOnline` / `dotOffline`) + toggle → toasts "✅ You are now online" / "⏸️ You are offline".
- **Incoming delivery request** (socket `DELIVERY_REQUEST`): toast "🛵 New delivery request!", **30 s countdown**, Accept / Decline; auto-clears if the order is cancelled ("Order was cancelled").
- **Auto-redirect:** if the rider has an active order, the dashboard immediately navigates to `/order/:id` (polls every 10 s).
- Dashboard stats block and the rest of the JSX ❓ (truncated).

### Order assigned
- Header `←`, "Order #{n}", raw status text (`status.replace('_',' ')`).
- **Map** (zoom 13): 🏪 "Pickup: Restaurant" and 🏠 "Drop: Customer" markers.
- **Info card:** "🏠 Drop Address" and further rows ❓.
- **Actions:** *Mark picked up* → *Delivered* form with **OTP input + "cash collected" (Rs)** → *Delivery failed* (note "Customer unavailable").
- **Background behaviour:** `watchPosition` → emits location at most every 4 s while on this screen.

### Earnings
Placeholder only: 💰 "Earnings history will show here after your first delivery".

### Profile
Avatar initial, name, phone, ⚙️ Settings / ❓ Help (both "coming soon"), "Sign Out".

> ❓ I could not see how the rider reaches `/earnings` and `/profile` from the dashboard (JSX truncated).

---

## A8. Admin panel — page-by-page

### Shell ✅
```
┌──────────────┬───────────────────────────────────────────┐
│ 🍔 FastFood  │ admin-header: [📊 Page title]   (A) Name  │
│ Admin Panel  ├───────────────────────────────────────────┤
│              │                                           │
│ 📊 Dashboard │              admin-content                │
│ …nav items…  │                                           │
│              │                                           │
│ 🚪 Sign Out  │                                           │
└──────────────┴───────────────────────────────────────────┘
```
- Header title is derived from the pathname: 📊 Dashboard · 🧾 Orders · 🍔 Menu Manager · 🏍️ Riders · 👥 Customers · 📈 Analytics.
- Avatar = 32 px primary-coloured circle with the user's initial.
- **Live toast** on socket `order:new`: "🔔 New order #{n} — Rs. {amount}", 6 s, orange `rgba(249,115,22,0.9)`, white bold text; also invalidates `orders` and `dashboard` queries.

### Login
Centered column (max 400 px) on `--bg`: 64 px 🍔, "FastFood" in `--primary`, "Admin Panel — Staff Access Only"; card (`--surface`, 1 px border, radius 16, padding 28) with Phone/Email, Password, full-width `btn btn-primary`. Rejects non admin/staff roles ("Access denied — admin or staff only").
🚨 **It prints "Default admin: +923001111111 / admin123456" under the button.**

### Dashboard
1. **4 stat cards** (`stat-grid`): Today's Revenue (`text-primary`, "From delivered orders") · Active Orders (warning colour + "N need attention", else "All clear") · Today's Orders ("N delivered") · Online Riders (`text-success`, "of N total").
2. **`grid-2`:** left = *Revenue — Last 7 Days (Rs.)* area chart (200 px); right = *🔴 Live Orders* (top 5 active, `#number`, item count, status badge, "View all →"; empty text "No active orders right now").
3. **Recent Orders** table (last 8) with "All orders →".
Refreshes every 15 s. Stats are computed client-side from `GET /orders?limit=100`.

### Orders
- Header: `page-title` + search input (220 px, "Search by order #…").
- **Filter pills** (radius 20): ALL (with count) + 9 statuses; active pill = `--primary` bg / white text.
- **Table** columns: Order # · Customer · Items (first 2, then "+N more") · Total · Payment (uppercase, default COD) · Status (`badge badge-{status}`) · Placed · **Actions**.
- **Action buttons** come from a `TRANSITIONS` map: `✅ Accept`, `❌ Reject`, `👨‍🍳 Prepare`, `📦 Ready`, `🏍️ Assign`; red (`btn-danger`) for REJECTED/CANCELLED, green (`btn-success`) otherwise.
- Loading / empty rows: centred muted text, 40 px padding. Polls every 10 s.

### Menu Manager
- Header: title + **segmented control** (🍔 Items | 📂 Categories) + "+ Add Item" (items tab only).
- **Items table:** emoji (24 px) + name + single-line ellipsised description (max 240 px) · category · price (`text-primary`) · **availability toggle (🟢/🔴 emoji button)** · `✏️ Edit` / `🗑️` (native `confirm()`).
- **Categories tab:** responsive grid `repeat(auto-fill, minmax(200px, 1fr))`, gap 16; each card = 40 px icon, name, "N items".
- **Create/Edit form** (modal/panel ❓ JSX truncated): fields known from code — name, description, base price **in Rs (converted to paisa on save)**, emoji, category, availability, image upload (`/uploads/image`, preview via `imageUrl`).

### Riders
- Header: title + two mini stat cards (Online — green, Total).
- **Table:** avatar (36 px, `--primary`) + name + `SUSPENDED` chip · phone · status badge (`● Online` / `○ Offline`) · deliveries · **Unsettled Cash** (amber when > 0) · actions: `💰 Settle` (only if cash > 0), `🚫 Suspend` / `✅ Restore`. Polls every 15 s.

### Customers
Header + search (260 px: name/phone) · "{n} customers found" · table: avatar (`--info`) + name + chip · phone · email · joined (`en-PK`, e.g. "21 Oct 2026") · status badge (reuses `badge-delivered` = Active, `badge-cancelled` = Suspended) · `Suspend`/`Restore` with `confirm()`.

### Analytics
- **4 KPI cards:** Total Revenue · Avg Order Value · Total Orders · Cancellation Rate (`text-danger`).
- **Revenue Trend — Last 30 Days (Rs.)** area chart (240 px, x-axis `interval={4}`).
- **`grid-2`:** *Order Status Breakdown* donut (inner 55, outer 85, padding 3°, circle legend 8 px) · *Orders by Hour of Day* bar chart (24 buckets, x-axis `interval={3}`).
- *Top selling items* (computed, top 8) — rendering ❓ truncated.

### Chart style spec (copy this for any new chart) ✅
```
Grid:      strokeDasharray="3 3"  stroke="#374151"
Axes:      axisLine={false} tickLine={false}  tick fill #9ca3af  fontSize 10–12
Tooltip:   background #1f2937; border 1px solid #374151; borderRadius 8; color #f9fafb; fontSize 12–13
Area:      stroke #f97316, strokeWidth 2, gradient fill (stop 5% opacity .3–.4 → 95% opacity 0)
Pie:       innerRadius 55, outerRadius 85, paddingAngle 3, colours from COLORS[]
Legend:    iconType="circle" iconSize={8}, label colour #9ca3af, 11px
```

---

## A9. Cross-app UX patterns

| Pattern | How it works today |
|---|---|
| **Session restore** | Identical `useEffect` in all three `App.tsx`: if a persisted `refreshToken` exists → `POST /auth/refresh` → `GET /users/me` → else `logout()`. |
| **Role gating (UI)** | Login screens check `role` after sign-in (`rider`, or `admin`/`staff`). |
| **Loading** | Customer: `.skeleton` blocks. Admin: "Loading…" table row. Rider: plain "Loading…" text. |
| **Empty state** | Big emoji + one muted sentence + optional CTA (cart, orders, earnings, tables). |
| **Errors** | `toast.error(err?.response?.data?.message ?? '<fallback>')` everywhere. |
| **Success** | `toast.success('…')`, often with an emoji. |
| **Destructive confirm** | Native `confirm()` / `prompt()` (cart clear, cancel order, delete item, suspend user). |
| **Money** | Integer paisa; display via `formatMoneyCompact`. Forms convert Rs ↔ paisa at the edge (`× 100`, `Math.round`). |
| **Back navigation** | `←` text button in header → `navigate(-1)` or an explicit route. |
| **Clickable card with inner button** | Outer `onClick` navigates; inner button calls `e.stopPropagation()`. |

**Polling intervals:** customer orders 10 s · order detail 8 s · track 15 s · rider active order 10 s · admin dashboard 15 s · admin orders 10 s · admin riders 15 s.
**Socket events:** `join:order`, `SocketEvents.RIDER_LOCATION_EMIT / _UPDATE`, `DELIVERY_REQUEST`, `DELIVERY_REQUEST_CANCELLED`, `order:new`.

---

## A10. Order-status design map

Single source of truth for the enum: `packages/shared-types/src/enums.ts` → `OrderStatus`.

| Status | Customer label (`STATUS_LABEL`) | Customer badge class | Admin badge class | Admin action button |
|---|---|---|---|---|
| `PLACED` | Order Placed | `status-placed` | `badge-placed` | ✅ Accept / ❌ Reject |
| `ACCEPTED` | Accepted | `status-accepted` | `badge-accepted` | 👨‍🍳 Prepare |
| `PREPARING` | Preparing | `status-preparing` | `badge-preparing` | 📦 Ready |
| `READY` | Ready | `status-ready` | `badge-ready` | 🏍️ Assign |
| `RIDER_ASSIGNED` | Rider Assigned | `status-rider-assigned` | `badge-rider-assigned` | — (rider drives) |
| `PICKED_UP` | On the way | `status-picked-up` | `badge-picked-up` | — |
| `DELIVERED` | Delivered | `status-delivered` | `badge-delivered` | — |
| `CANCELLED` | Cancelled | `status-cancelled` | `badge-cancelled` | — |
| `REJECTED` | Rejected | `status-rejected` | `badge-rejected` | — |
| `DELIVERY_FAILED` | Delivery Failed | `status-delivery-failed` | `badge-delivery-failed` | — |

- **Class derivation:** `status.toLowerCase().replace('_','-')` → hyphenated.
- **"Active" (customer):** PLACED, ACCEPTED, PREPARING, READY, RIDER_ASSIGNED, PICKED_UP.
- **"Terminal/inactive" (admin dashboard):** DELIVERED, CANCELLED, REJECTED, DELIVERY_FAILED.
- Action-button rows are from the labels seen in code; the exact `TRANSITIONS` map ❓ is in `OrdersPage.tsx`.
- The matching CSS rules for each `status-*` / `badge-*` class ❓ must exist in global CSS — verify all 10 exist for **both** systems.

---

## A11. Platform & responsive notes

- **Customer & Rider** are web apps wrapped by **Capacitor 8 (Android)**. Installed plugins: app, browser, haptics, network, status-bar, geolocation, splash-screen. Customer has `lib/lifecycle.ts → registerAppLifecycle()`. Whether haptics / network / status-bar styling are used in the UI ❓.
- **Safe areas:** the sticky cart bar and `BottomNav` should respect `env(safe-area-inset-bottom)` — ❓ check CSS.
- **Rider GPS:** uses the browser `navigator.geolocation.watchPosition` inside the order screen (high accuracy, ≤1 emit per 4 s). The overview also mentions background geolocation in the native layer.
- **Admin:** a fixed sidebar layout with data tables. No mobile breakpoint evidence in TSX ❓. Treat it as **desktop-only (≥1024 px)** until CSS proves otherwise.
- **Theme:** admin = dark only. No light/dark toggle in any app.

---

## A12. Design audit — what to fix (prioritised)

### P1 — fix first
1. **Default admin credentials shown on the login screen** (`LoginPage.tsx`). Remove the line.
2. **Checkout location UX.** Customers see raw Latitude/Longitude fields, pre-filled with a **hard-coded Lahore centre**. The hint says "auto-filled", but the value is not from GPS, even though `@capacitor/geolocation` is installed. A customer who doesn't edit it orders to the wrong place. → Use device GPS + a draggable map pin; hide the numbers.
3. **Native `confirm()` / `prompt()`** for clear cart, cancel order (reason), delete menu item, suspend user. Off-brand, unstyled, and unreliable in an Android WebView. → Build one themed `ConfirmDialog` / bottom sheet.
4. **Admin can't filter failed deliveries.** `OrdersPage` `STATUSES` omits `DELIVERY_FAILED`.

### P2 — consistency
5. **Two badge systems** (`status-*` vs `badge-*`) and two label sources (`STATUS_LABEL` in customer, raw `status.replace(...)` in admin/rider).
6. **Admin inline-style sprawl.** Avatars, "SUSPENDED" chip, filter pills, segmented control, empty-state rows, and `fontFamily: 'Inter'` are repeated inline across pages. → Extract classes (`.avatar`, `.chip-danger`, `.pill`, `.segmented`, `.table-empty`) and set the font once on `body`.
7. **Rider login drift:** uses `styles.label` / `styles.error` while customer uses global `label` / `error-text`; password field has no inline error.
8. **Password rules differ** (login min 6, signup min 8).
9. **Rider map `TileLayer` has no attribution** (customer map does). OpenStreetMap requires attribution; also review OSM's tile-usage policy before real traffic.
10. **Colour-only / emoji-only status:** menu availability 🟢/🔴 and online dot convey state by colour alone. Add text or `aria-label`. Emoji also render differently across Android versions.
11. **Placeholder features visible to users:** Saved Addresses, Settings, Help (customer); Settings, Help, Earnings (rider). Hide or label "Coming soon" visually.
12. **Raw enums leak to users:** Track screen fallback prints `order.status`; rider header prints `status.replace('_',' ')`.

### P3 — polish & hygiene
13. Promo cards and fallback colours are hard-coded in TSX (`#fed7aa`, `#fde68a`, `#fce7f3`); promos aren't data-driven.
14. Delivery threshold (Rs 1,000) and fee (Rs 100) are hard-coded in `CartScreen`; risk of drifting from the server. → read from `/app-config`.
15. Admin charts compute from the first 100/500 orders — numbers silently truncate on busy days. "Orders by Hour" is called a *heatmap* but is a bar chart.
16. `.replace('_','-')` only replaces the **first** underscore; use `/_/g` for any future status with two underscores (admin `OrdersPage` already does).
17. Accessibility gaps: icon-only buttons (`←`, `+`, `✕`, `🛒`) have no `aria-label`; focus rings and `--text-muted` contrast on dark ❓ not verified.
18. Only some components are shared; `MenuItemCard`, `OrderCard`, `CategoryChip` are file-local. Candidates for a shared package.

---

## A13. What I could not verify (please check these files)

| Item | Where to look |
|---|---|
| Real values of `--bg`, `--surface`, `--border`, `--primary`, `--success`, `--warning`, `--danger`, `--info`, `--text-muted` | `apps/*/src/index.css` (or wherever the global CSS is imported) |
| Font family & sizes for customer / rider | Same global CSS + each `*.module.css` |
| CSS for every `status-*` and `badge-*` class | Global CSS |
| `.skeleton` animation, `.bottom-nav` height, safe-area handling | Global CSS |
| Remaining `STATUS_STEPS` entries and `NAV` entries | `OrderDetailScreen.tsx`, `Sidebar.tsx` |
| Checkout payment block, Menu item form, Dashboard recent-orders table, Analytics "top items" | Truncated in graph output — open the files |
| Rider dashboard stats and how Earnings/Profile are reached | `DashboardScreen.tsx` |
| Whether haptics / status-bar / network plugins affect UI | Search `@capacitor/` imports in `apps/*/src` |
| Admin behaviour below 1024 px | Global CSS media queries |

---
---

# PART B — CODING INSTRUCTIONS FOR DESIGN DEVELOPERS

## B1. Quick start

```bash
# Requirements (from repo docs): Node 20+, pnpm 9+
git clone https://github.com/Ahsan3727/fast-food-management-system
cd fast-food-management-system
pnpm install
```

- Run an app with the dev script in its own `package.json` (`apps/customer`, `apps/rider`, `apps/admin`). I could not see the script names, so check `scripts` there — it's usually `pnpm dev` inside the app folder. 🔶
- The apps talk to the API under `/v1` (REST) and Socket.IO. Check each app's `.env*` / `vite-env.d.ts` for the API and `SOCKET_URL` variable names ❓.
- Customer and Rider also ship as Android builds through Capacitor — test layout in **Chrome DevTools mobile mode first**, then on a device.
- The repo currently has **no tests and no CI**. Run `pnpm build` yourself before pushing.

## B2. Where things live

```
apps/
  customer/src/
    App.tsx                 routes + auth guards
    screens/*.tsx           one file per screen  (+ matching *.module.css) 🔶
    components/BottomNav.tsx
    lib/lifecycle.ts
  rider/src/
    App.tsx
    screens/*.tsx           Dashboard, OrderAssigned, Earnings, Profile, Login
  admin/src/
    App.tsx                 routes + AdminLayout (+ order:new socket)
    pages/*.tsx             Dashboard, Orders, Menu, Riders, Customers, Analytics, Login
    components/Sidebar.tsx
packages/
  shared-types/             enums (OrderStatus, RoleType, SocketEvents…), Zod schemas
  utils/                    formatMoneyCompact, formatDateTime, timeAgo…
```

## B3. Golden rules

1. **Never compute final prices in the UI.** Show estimates labelled **"(est.)"** and keep the server note ("Final price calculated at checkout by server").
2. **Money is integer paisa.** Display with `formatMoneyCompact`. Convert Rs → paisa only at the form boundary: `Math.round(parseFloat(v) * 100)`.
3. **Use enums, not string literals,** for statuses/roles/socket events (`@fastfood/shared-types`). New code must not retype `'PICKED_UP'`.
4. **Styling location:**
   - Customer/Rider → a **CSS Module per screen** (`styles.xyz`) + the global primitives (`btn-primary`, `input`, `label`, `error-text`, `skeleton`).
   - Admin → **global classes** from A4. **Do not add new inline `style={{…}}`** — add a class instead.
5. **Colours only via CSS variables** (`var(--primary)` …). No new hex values in TSX. The one exception is Recharts props — put those in a shared `chartTheme.ts`, not inline per chart.
6. **Every data view needs four states:** loading (skeleton), empty (emoji + sentence + CTA), error (toast with server message), success.
7. **Touch targets ≥ 44 × 44 px** on customer & rider. Keep bottom-fixed UI clear of `env(safe-area-inset-bottom)`.
8. **Icons:** the system is emoji. Don't mix in an SVG icon library on the same surface. Every meaningful emoji gets `role="img"` + `aria-label`; decorative ones get `aria-hidden="true"`.
9. **No new `confirm()` / `prompt()` / `alert()`.** Use a themed dialog (B5-R6).
10. **Clickable card with an inner button →** call `e.stopPropagation()` in the inner handler.
11. **Sockets:** connect in `useEffect`, disconnect in the cleanup. Only emit rider location from the active-order screen, throttled to ≥ 4 s.
12. **Copy:** short, friendly, sentence case, currency as `Rs.`, dates via `formatDateTime` / `en-PK`.
13. **Design PRs don't touch API or business logic.** If a UI needs new data, open a separate backend task.

## B4. Design tokens — proposed baseline

> **Proposal, not current state.** Values marked ✅ come from code; the rest are suggestions to *reconcile with the existing `index.css`* before adopting. Goal: one `tokens.css` shared by all three apps.

```css
:root {
  /* Brand */
  --primary: #f97316;            /* ✅ matches charts & toast */
  --primary-soft: rgba(249,115,22,.15);

  /* Semantic */
  --success: #22c55e;            /* ✅ chart palette green */
  --warning: #f59e0b;            /* ✅ chart palette amber */
  --danger:  #ef4444;            /* 🔶 from rgba(239,68,68,…) */
  --info:    #3b82f6;            /* ✅ chart palette blue */

  /* Dark surfaces (admin) */
  --bg:        #111827;          /* ❓ proposal */
  --surface:   #1f2937;          /* ✅ tooltip surface */
  --border:    #374151;          /* ✅ grid/tooltip border */
  --text:      #f9fafb;          /* ✅ */
  --text-muted:#9ca3af;          /* ✅ */

  /* Pastels for food tiles (customer) */
  --tile-orange:#fed7aa;         /* ✅ default tile */
  --tile-yellow:#fde68a;         /* ✅ */
  --tile-pink:  #fce7f3;         /* ✅ */

  /* Spacing — strict 4-pt scale (replace 6, 7, 10, 28) */
  --space-1:4px; --space-2:8px; --space-3:12px; --space-4:16px;
  --space-5:20px; --space-6:24px; --space-8:32px; --space-10:40px;

  /* Radius */
  --radius-sm:4px; --radius-md:8px; --radius-lg:16px; --radius-pill:999px;

  /* Type */
  --font: 'Inter', system-ui, sans-serif;
  --fs-xs:11px; --fs-sm:12px; --fs-md:14px; --fs-lg:20px; --fs-xl:28px;
}
```

Customer/rider are currently light-leaning, admin is dark, so a real shared file needs **light and dark token sets** (`:root` + `[data-theme="dark"]`). Agree on that with the owner before refactoring.

## B5. Recipes & templates

> Import lines below are placeholders — **copy the real import paths from an existing screen** (`HomeScreen.tsx`, `OrdersPage.tsx`); I could not see them.

### R1 — Add a customer screen

1. Create `apps/customer/src/screens/FavoritesScreen.tsx` + `FavoritesScreen.module.css`.
2. Register the route in `App.tsx` **inside `PrivateRoute`**.
3. Top-level tab? Add it to `BottomNav` items and extend the `active` prop type. Otherwise use a `←` header and no BottomNav.

```tsx
import { useNavigate } from 'react-router-dom';
import { useQuery } from '/* same package as other screens */';
import api from '/* same api client as other screens */';
import BottomNav from '../components/BottomNav';
import styles from './FavoritesScreen.module.css';

export default function FavoritesScreen() {
  const navigate = useNavigate();
  const { data: items = [], isLoading } = useQuery({
    queryKey: ['favorites'],
    queryFn: () => api.get('/favorites').then(r => r.data),
  });

  return (
    <div className={styles.page}>
      <div className={styles.header}><h1>Favorites</h1></div>

      {isLoading ? (
        <div className={styles.list}>
          {[1, 2, 3].map(i => <div key={i} className={`skeleton ${styles.skeleton}`} />)}
        </div>
      ) : (items as any[]).length === 0 ? (
        <div className={styles.empty}>
          <span>❤️</span>
          <p>No favorites yet</p>
          <button className="btn-primary" style={{ maxWidth: 180 }} onClick={() => navigate('/menu')}>
            Browse Menu
          </button>
        </div>
      ) : (
        <div className={styles.list}>{/* rows */}</div>
      )}

      <BottomNav active="profile" />
    </div>
  );
}
```

### R2 — Add an admin page

1. Create `apps/admin/src/pages/CouponsPage.tsx`.
2. Route in `App.tsx`: `<Route path="/coupons" element={<Private><AdminLayout><CouponsPage /></AdminLayout></Private>} />`.
3. Add an entry to `NAV` in `Sidebar.tsx` **and** a title line in `AdminLayout`'s header ternary (it is a hard-coded chain — consider turning it into a lookup object).

```tsx
export default function CouponsPage() {
  return (
    <div>
      <div className="flex-between" style={{ marginBottom: 20 }}>
        <h1 className="page-title" style={{ marginBottom: 0 }}>Coupons</h1>
        <button className="btn btn-primary">+ Add Coupon</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Code</th><th>Discount</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>{/* rows; loading + empty rows use colSpan and var(--text-muted) */}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
```

### R3 — Change or add an order status (touch all of these)

| # | File | Change |
|---|---|---|
| 1 | `packages/shared-types/src/enums.ts` | Add to `OrderStatus` |
| 2 | `apps/api/.../order.state-machine.ts` | Backend transitions (backend task) |
| 3 | `apps/customer/.../OrdersScreen.tsx` | `STATUS_LABEL`, `ACTIVE_STATUSES` |
| 4 | `apps/customer/.../OrderDetailScreen.tsx` | `STATUS_STEPS` (if it's part of the happy path) |
| 5 | Customer global CSS | `.status-<new-status>` |
| 6 | Admin global CSS | `.badge-<new-status>` |
| 7 | `apps/admin/.../OrdersPage.tsx` | `STATUSES` filter list + `TRANSITIONS` + button label/emoji |
| 8 | `DashboardPage.tsx` / `AnalyticsPage.tsx` | "active" / "cancelled" filters |

Derive the CSS class with a regex, not a string: `status.toLowerCase().replace(/_/g, '-')`.

### R4 — Form (react-hook-form) — canonical pattern

```tsx
const { register, handleSubmit, formState: { errors } } = useForm<FormValues>();
const [loading, setLoading] = useState(false);

const onSubmit = async (values: FormValues) => {
  setLoading(true);
  try {
    await api.post('/something', values);
    toast.success('Saved!');
  } catch (err: any) {
    toast.error(err?.response?.data?.message ?? 'Something went wrong');
  } finally {
    setLoading(false);
  }
};

<form onSubmit={handleSubmit(onSubmit)} className={styles.form}>
  <div>
    <label className="label">Phone Number</label>
    <input className="input" placeholder="+923001234567"
      {...register('phone', { required: 'Required', minLength: { value: 10, message: 'Invalid phone' } })} />
    {errors.phone && <p className="error-text">{errors.phone.message}</p>}
  </div>
  <button type="submit" className="btn-primary" disabled={loading}>
    {loading ? 'Saving…' : 'Save'}
  </button>
</form>
```
Rules: label above input · message under the field · button shows progressive text ("Saving…") and is disabled · **use one password min-length everywhere (propose 8)**.

### R5 — Mutation + toast (admin)

```tsx
const suspend = useMutation({
  mutationFn: ({ id, val }: { id: string; val: boolean }) => api.patch(`/users/${id}`, { isSuspended: val }),
  onSuccess: () => { toast.success('Updated'); qc.invalidateQueries({ queryKey: ['customers'] }); },
  onError: (e: any) => toast.error(e?.response?.data?.message ?? 'Failed'),
});
// disable the trigger while pending:  disabled={suspend.isPending}
```

### R6 — Replace `confirm()` / `prompt()` (proposal)

Build once, reuse everywhere:

```tsx
// components/ConfirmDialog.tsx  — proposed shared component
type Props = {
  open: boolean;
  title: string;
  message?: string;
  confirmLabel?: string;       // e.g. "Delete", "Suspend"
  tone?: 'danger' | 'primary';
  withReason?: boolean;        // replaces prompt('Reason for cancellation?')
  onConfirm: (reason?: string) => void;
  onCancel: () => void;
};
```
Requirements: focus trap, `Esc` to close, backdrop click = cancel, destructive action uses `btn-danger`, bottom-sheet layout on customer/rider, centered modal on admin.

### R7 — New admin chart

Start from the **Chart style spec** in A8. Keep colours in a constant:

```ts
// chartTheme.ts (proposed)
export const chart = {
  grid: '#374151', tick: '#9ca3af', tooltipBg: '#1f2937', tooltipBorder: '#374151', tooltipText: '#f9fafb',
  brand: '#f97316',
  palette: ['#f97316', '#3b82f6', '#22c55e', '#f59e0b', '#a78bfa', '#ec4899'],
};
```
Always wrap in `<ResponsiveContainer width="100%" height={…}>` and set a numeric height (200 for dashboard cards, 220–240 for analytics).

### R8 — Map marker (Leaflet)

```tsx
const dropIcon = L.divIcon({
  html: '<div style="font-size:28px;line-height:1" role="img" aria-label="Drop-off">🏠</div>',
  iconSize: [28, 28],
  iconAnchor: [14, 28],   // bottom-centre so the pin tip is on the coordinate
  className: '',          // removes Leaflet's default white box
});

<MapContainer center={[lat, lng]} zoom={14} zoomControl={false} style={{ height: '100%', width: '100%' }}>
  <TileLayer
    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'  /* always include */
  />
  <Marker position={[lat, lng]} icon={dropIcon}><Popup>Your delivery address</Popup></Marker>
</MapContainer>
```
The map wrapper must have an explicit height (the screens use a `mapWrap` class) or the map renders at 0 px.

### R9 — Clickable card with inner action

```tsx
<div className={styles.itemCard} onClick={() => navigate(`/menu/${item._id}`)}>
  …
  <button className={styles.addBtn} aria-label={`Add ${item.name}`}
          onClick={(e) => { e.stopPropagation(); onAdd(); }}>+</button>
</div>
```

### R10 — Toast conventions

| Type | Rule | Example |
|---|---|---|
| Success | ≤ 6 words, optional emoji | `toast.success('Item updated!')` |
| Error | Prefer server message, always have a fallback | `toast.error(err?.response?.data?.message ?? 'Login failed')` |
| Info | `toast('…')` with leading emoji | `toast('🛵 New delivery request!')` |
| Brand alert (admin new order) | 6 s, orange bg, white 700 text | see `AdminLayout` |
| Not-built-yet | **Avoid** — hide the feature instead of `toast('Settings coming soon')` |

## B6. Accessibility checklist

- [ ] Icon-only buttons have `aria-label` (`←` → "Back", `+` → "Add {item}", `✕` → "Clear search", `🛒` → "Open cart").
- [ ] Meaningful emoji have `role="img"` + `aria-label`; decorative emoji `aria-hidden="true"`.
- [ ] State is never colour-only (🟢/🔴, online dot → add text like "Available" / "Online").
- [ ] `--text-muted` on `--surface` meets 4.5:1 contrast (check in both themes).
- [ ] Visible `:focus-visible` outline on every button, pill, and nav item.
- [ ] Form inputs have a real `<label>` (`htmlFor`/`id`) — current labels are visually adjacent only ❓.
- [ ] Dialogs trap focus, close on `Esc`, restore focus.
- [ ] Tap targets ≥ 44 px; spacing ≥ 8 px between adjacent buttons (qty `−` / `+`).
- [ ] Respect `prefers-reduced-motion` for skeleton shimmer and any new animation.

## B7. Pull-request checklist (design changes)

- [ ] Screenshots: **before / after**, 360 px wide (customer/rider) or 1440 px (admin).
- [ ] Loading, empty, error, and populated states all shown.
- [ ] No new inline hex colours or `style={{}}` blocks (admin) — or justified in the PR.
- [ ] Uses existing global classes/tokens; any new class is added to the vocabulary in A4.
- [ ] Statuses use enums; both badge systems updated if a status changed (R3).
- [ ] No `confirm()`, `prompt()`, `alert()` introduced.
- [ ] Money shown via `formatMoneyCompact`; estimates marked "(est.)".
- [ ] Android check done for customer/rider (safe areas, keyboard overlap on checkout, back button).
- [ ] `pnpm build` passes for the touched app.
- [ ] Accessibility checklist (B6) ticked.

## B8. Suggested work order for a design developer

Ordered so that each step makes the next easier:

1. **Read the real CSS** and fill in the ❓ rows in A13; update this document.
2. **Remove default credentials** from the admin login (one-line change, high value).
3. **Create `tokens.css`** (B4) and point all three apps at it.
4. **Unify badges:** one `.badge` family used by customer, rider, and admin; delete the duplicate.
5. **Build `ConfirmDialog`** (R6) and replace every native `confirm()` / `prompt()`.
6. **Extract admin utility classes** (`.avatar`, `.chip-danger`, `.pill`, `.segmented`, `.table-empty`) and delete repeated inline styles.
7. **Checkout location picker** (GPS + draggable pin) replacing the lat/lng inputs.
8. **Create `@fastfood/ui`** (new workspace package) with `BottomNav`, `StatusBadge`, `EmptyState`, `Skeleton`, `ConfirmDialog`, `Avatar`; move file-local cards in gradually.
9. **Add `DELIVERY_FAILED`** to admin filters; add attribution to the rider map.
10. **Hide or finish placeholder screens** (Saved Addresses, Settings, Help, Earnings).
11. **Accessibility pass** (B6), then add Storybook or a `/design` route as a living reference.

## B9. Known pitfalls

- **Backend gaps affect UI:** admin Customers/Riders pages call `GET /users?role=…` and `PATCH /users/:id`, which the overview reports are **not exposed** by `UsersController` yet — those pages may show empty tables until the API is fixed. Rider "Unsettled Cash" stays at 0 because cash isn't incremented on delivery. Don't "fix" these in CSS.
- **Rider online flag** lives in two collections (`riders` vs `users`), so the admin "Online" count can disagree with the rider app.
- **Query keys are shared** (`['orders']`, `['menu']`, `['riders-all']`) between pages with *different* `limit`s (100 vs 200 vs 500) — React Query will serve the first cached result. Use distinct keys when the query differs.
- **Map height:** a Leaflet map inside a flex parent with no explicit height renders blank.
- **Polling + sockets:** customer screens poll *and* use sockets; don't add a third refresh mechanism.
- **Free-tier API** may cold-start (the overview mentions Render/Spaceship free tiers): design loading states for slow first requests.

---

*End of document. Update Part A whenever a screen, token, or class changes; Part B whenever a convention changes.*
