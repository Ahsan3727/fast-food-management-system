# FastFood — Design Overview (A to Z)

**Repository:** `Ahsan3727/fast-food-management-system`
**Analysed commit:** `51785e2` (indexed by Graphify on 2026-10-20, 1,167 nodes / 1,780 edges)
**Written:** 21 October 2026
**Scope:** The three user-facing apps — `apps/customer`, `apps/rider`, `apps/admin`. The API is covered only where it changes what the UI shows.
**Companion file:** `DESIGN_DEVELOPER_GUIDE.md` (coding instructions for design developers)

---

## 0. How to read this document

Every statement carries a confidence marker so a design developer knows what to trust.

| Marker | Meaning |
|---|---|
| ✅ | **Verified.** Read directly in source code at commit `51785e2`. |
| 🟡 | **Inferred.** Strongly implied by the code, but the defining file was not readable. |
| ❓ | **Not verified.** Lives in a file the code graph does not expose. Open the file listed in §17 to confirm. |

**What the graph could not read:** `.css` / `.module.css` files, `main.tsx` bodies, `index.html`, `capacitor.config.*`, and the tail of three long components (`DashboardScreen`, `OrderAssignedScreen`, `CheckoutScreen`). That means **exact token values for most colours, fonts and spacing are ❓**. Where a value leaked into TypeScript (chart colours, toast styles, inline styles, emoji backgrounds) it is recorded as ✅.

---

## 1. Product and surfaces

FastFood is a single-restaurant, cash-on-delivery ordering system. Three front-ends share one NestJS API.

| Surface | Users | Form factor | Theme | Screens |
|---|---|---|---|---|
| **Customer** (`apps/customer`) | Customers | Mobile-first, React + Capacitor Android | 🟡 Light (pastel promo colours, see §3.2) | 12 |
| **Rider** (`apps/rider`) | Delivery partners | Mobile-first, React + Capacitor Android | ❓ | 5 |
| **Admin** (`apps/admin`) | Owner and staff | Desktop web (Vercel) | ✅ Dark | 7 |

Locale is Pakistan: currency `Rs.` in integer paisa, dates and numbers formatted with `en-PK`, default map centre Lahore (`31.5204, 74.3587`) ✅.

---

## 2. UI technology stack

All versions from each app's `package.json` ✅.

| Concern | Library | Used in |
|---|---|---|
| UI framework | React 18.3.1 + Vite + TypeScript | all |
| Routing | `react-router-dom` 6.27 | all |
| Server state | `@tanstack/react-query` 5.59 | all |
| Client state | `zustand` 5 (auth stores, cart store) | all |
| Forms | `react-hook-form` 7.53 (customer, rider); plain `useState` forms in admin Login | all |
| Notifications | `react-hot-toast` 2.4 | all |
| Maps | `react-leaflet` 4.2.1 + OpenStreetMap tiles | customer, rider |
| Charts | Recharts (`AreaChart`, `BarChart`, `PieChart` usage ✅) | admin |
| Realtime | Socket.IO client | all |
| Native shell | Capacitor 8: `android`, `app`, `browser`, `geolocation`, `haptics`, `network`, `splash-screen`, `status-bar` | customer, rider |
| Money / date | `@fastfood/utils` (`formatMoney`, `formatMoneyCompact`, `formatDate`, `formatDateTime`) | all |

**Styling approach** ✅ for the mechanism, ❓ for the contents:

- Customer and rider screens import a **CSS Module per screen** (`styles.page`, `styles.header`, `styles.card`…) and also use **global classes** (`btn-primary`, `input`, `label`, `error-text`, `skeleton`, `bottom-nav`).
- Admin uses **global classes** (`card`, `btn`, `badge`, `stat-card`, `table-wrap`…) **plus a large amount of inline `style={{…}}`**.
- `*.module.css` typings are declared in all three `vite-env.d.ts` files ✅.
- No Tailwind or component-kit usage is visible 🟡 (all class names are custom).
- **There is no shared design package.** `@fastfood/shared-types` and `@fastfood/utils` carry types and helpers only. Each app owns its own stylesheet.

---

## 3. Design language

### 3.1 Brand

| Item | Value | Status |
|---|---|---|
| Name | **FastFood** | ✅ |
| Logo | 🍔 emoji (customer, admin); 🏍️ emoji (rider) | ✅ |
| Customer tagline | "Fresh, fast, and delivered" (login), "Create your account" (signup) | ✅ |
| Rider title | "Rider Portal — FastFood Delivery Partner" | ✅ |
| Admin title | "Admin Panel — Staff Access Only" | ✅ |
| Tone | Friendly, emoji-led, conversational ("What are you craving today?") | ✅ |

There is no real logo asset, icon font, or SVG sprite. Splash and launcher icons live in the Android project and were not readable ❓.

### 3.2 Colour

Brand orange is the only colour that is confirmed in several places.

| Role | Value | Evidence | Status |
|---|---|---|---|
| **Primary (brand orange)** | `#f97316` (Tailwind orange-500) | Chart stroke and fill in admin Dashboard and Analytics; admin new-order toast background `rgba(249,115,22,0.9)` | ✅ value, 🟡 that it equals `--primary` |
| Admin surface | `#1f2937` | Chart tooltip background | ✅ value, 🟡 that it equals `--surface` |
| Admin border / grid | `#374151` | Chart grid, tooltip border | ✅ value, 🟡 `--border` |
| Admin muted text | `#9ca3af` | Chart axis ticks, pie legend | ✅ value, 🟡 `--text-muted` |
| Admin text | `#f9fafb` | Tooltip text | ✅ value |
| Danger tint | `rgba(239,68,68,0.15)` background + `var(--danger)` text | "SUSPENDED" tag | ✅ (red-500 base) |
| Promo peach | `#fed7aa` | Default food-card background; "Fresh today" promo | ✅ |
| Promo amber | `#fde68a` | "Hot deals" promo | ✅ |
| Promo pink | `#fce7f3` | "New arrivals" promo | ✅ |
| Pie chart palette | `COLORS[]` array | Admin Analytics | ❓ |

**CSS variable names in use** (names ✅, values ❓): `--bg`, `--surface`, `--border`, `--primary`, `--text-muted`, `--success`, `--warning`, `--danger`, `--info`.

Food cards fall back to `item.color ?? '#fed7aa'`, so each menu item can carry its own tint ✅.

### 3.3 Typography

| Item | Value | Status |
|---|---|---|
| Admin font | `Inter, sans-serif` (set inline on pill and tab buttons) | ✅ |
| Customer / rider font | — | ❓ |
| Weights seen | 600 (labels, tabs), 700 (titles, order numbers), 800 (brand, stat values, avatars) | ✅ |
| Sizes seen (px) | 64 logo, 40 category icon, 28 brand title, 22 stat value, 20 form title, 15 header, 14 body, 13 table secondary, 12 meta and pills, 11 captions, 10 tags | ✅ |

### 3.4 Shape and spacing

| Item | Values seen | Status |
|---|---|---|
| Radius (px) | 16 (auth card, skeleton), 8 (tab group, tooltip), 20 (filter pills), 4 (tags), 50% (avatars) | ✅ |
| Spacing (px) | 4, 6, 8, 10, 12, 16, 20, 24, 28, 40 (an informal, mostly 4-based scale) | ✅ |
| Max widths | Admin login card 400; admin category grid `repeat(auto-fill, minmax(200px, 1fr))` | ✅ |
| Avatar size | 36 (table rows), 32 (header) | ✅ |

### 3.5 Iconography — emoji only

Every icon in all three apps is an emoji character. No icon library is installed ✅.

| Meaning | Emoji | Where |
|---|---|---|
| Brand / food | 🍔 🍕 🥤 🍰 🥗 🍽️ | Logo, categories, fallback item image |
| Cart | 🛒 | Home header, empty cart |
| Search | 🔍 | Home search bar |
| Rider | 🏍️ 🛵 | Rider logo, tracker, toasts |
| Places | 🏠 (drop) 🏪 (restaurant) 📍 (landmark) | Map markers, detail screens |
| Orders | 📦 📋 | Empty orders, tracker step 1 |
| Status / feedback | ✅ ❌ 🎉 🔔 ⏸️ 🔴 🟢 | Toasts, banners, availability toggle |
| Admin actions | 👨‍🍳 Prepare, 📦 Ready, 🏍️ Assign, 💰 Settle, 🚫 Suspend, ✏️ Edit, 🗑️ Delete | Admin tables |
| Admin nav | 📊 Dashboard, 🧾 Orders, 🍔 Menu Manager, 🏍️ Riders, 👥 Customers, 📈 Analytics, 🚪 Sign Out | Sidebar and header |
| Disclosure | `›` text chevron; `←` text back arrow; `✕` clear | Profile rows, back buttons, search |

### 3.6 Motion

- Loading shimmer via a global `.skeleton` class (class ✅, animation ❓).
- Rider delivery request: a 30-second countdown ✅.
- Toast entrance/exit (react-hot-toast default).
- No page transitions, no list animations, no gesture handling were found.

### 3.7 Layout archetypes

| App | Archetype |
|---|---|
| Customer | Single column, full-height page, sticky header, content scroll, **fixed bottom tab bar** (`.bottom-nav`) on tab screens, floating **cart summary bar** above it on Home |
| Rider | Single column cards over a map; no tab bar found |
| Admin | **Sidebar + header + content** shell (`admin-layout` → `admin-sidebar`, `admin-main` → `admin-header`, `admin-content`); stat grids; data tables inside cards |

---

## 4. Global class registry (observed from usage)

These classes are used in TSX but defined in CSS that was not readable. Treat the **names** as the API ❓ for their definitions.

**Customer / rider (global)**
`btn-primary` · `input` · `label` · `error-text` · `skeleton` · `bottom-nav` · `bottom-nav-item` (+ `active`) · `status-badge` · `status-<slug>`

**Admin (global)**
Layout: `admin-layout` · `admin-main` · `admin-header` · `admin-content` · `admin-sidebar` · `sidebar-brand` · `sidebar-brand-icon` · `sidebar-brand-name` · `sidebar-brand-sub` · `sidebar-nav` · `sidebar-bottom` · `nav-item` (+ `active`) · `nav-icon`
Content: `page-title` · `card` · `card-title` · `grid-2` · `stat-grid` · `stat-card` · `stat-label` · `stat-value` · `stat-delta` · `delta-up` · `table-wrap`
Controls: `btn` · `btn-primary` · `btn-ghost` · `btn-success` · `btn-danger` · `btn-sm` · `input` · `label` · `input-group`
Status: `badge` · `badge-<slug>` · `badge-online` · `badge-offline`
Utility: `flex-between` · `flex-gap` · `mt-16` · `font-bold` · `text-primary` · `text-success` · `text-danger` · `text-muted`

> ⚠️ `btn-primary` means **different things** in the two apps: customer uses it alone (`className="btn-primary"`), admin pairs it (`className="btn btn-primary"`). See issue D9.

---

## 5. Customer app — screen by screen

### 5.1 Navigation map ✅

```
 /login ◄──────► /signup                       (public only)
    │
    ▼  authenticated
   /  Home ───► /search ───────────┐
    │  │                           │
    │  └─► /menu?category=:id ─────┤
    ▼                              ▼
  /menu ───────────────────► /menu/:id  (product detail)
                                   │  Add to cart (toast, goes back)
                                   ▼
                                /cart ──► /checkout ──► /orders/:id
                                                          │
 BottomNav: Home · Menu · Orders · Profile                ▼
 (home, menu, orders, profile, search→menu tab)     /orders/:id/track
```

Route guards: `PrivateRoute` redirects to `/login`; `PublicRoute` redirects authenticated users to `/`. Session is restored on launch from a persisted refresh token ✅.

Bottom tab bar appears on: Home, Menu, Search (highlights Menu), Orders, Profile. It does **not** appear on Product detail, Cart, Checkout, Order detail, or Track ✅.

### 5.2 Screens

| Screen | Route | Purpose | Layout, top to bottom | States handled |
|---|---|---|---|---|
| **Login** | `/login` | Sign in | Hero (🍔 logo, "FastFood", tagline) → card: "Welcome back", identifier + password, **Sign In** → link to Sign up | Field errors, loading text "Signing in…", error toast |
| **Signup** | `/signup` | Register | Hero → card "Get started": name, phone, optional email, password, confirm → **Create Account** | Min-length and match validation, loading, error toast |
| **Home** | `/` | Discover | Header (greeting, cart button + badge) → fake search bar (navigates to Search) → promo row (3 pastel cards) → "Categories" chip row + "See all →" → "🔥 Popular" 2-col grid (first 12 items) → floating **cart bar** (count · "View Cart" · total) → bottom nav | Skeleton grid (6), fallback categories (Burgers, Pizza, Drinks, Desserts) when API returns none |
| **Menu** | `/menu` | Browse and filter | Back + title → horizontal filter pills (All + categories, synced to `?category=`) → list rows (image/emoji, name, description, price, **+**) → bottom nav | Skeleton rows (4) |
| **Product detail** | `/menu/:id` | Configure item | Hero (item colour, image or big emoji, back button) → name, description → **Size** option buttons (Regular + sizes, with prices) → **Add-ons** toggle buttons (`+Rs.`) → **Quantity** stepper → **Add to cart** | Skeleton, "Item not found"; success toast then navigates back |
| **Search** | `/search` | Find items | Back + autofocus input + clear ✕ → hints → result rows (emoji, name, price) → bottom nav | "Type at least 2 characters", "Searching…", "No results for…" |
| **Cart** | `/cart` | Review | Header "Cart (n)" + Clear → rows (emoji, name, size, add-ons, line price, − qty +) → summary (Subtotal, Delivery, free-delivery hint, Total est., note "Final price calculated at checkout by server") → **Proceed to Checkout** | Empty cart screen with **Browse Menu** |
| **Checkout** | `/checkout` | Place order | Header → Order summary → **Delivery address** (textarea, landmark, **latitude + longitude inputs**) → Payment (COD) → submit | Validation (min 10 chars), loading, error toast; empty cart redirects to `/cart` |
| **Orders** | `/orders` | History | Title → "🔴 Active Orders" group → "Past Orders" group → bottom nav. Card: `#number`, time ago, status badge, item count, total, **🗺️ Track Order** (active only) | Skeleton (3), empty ("📦 No orders yet" + **Order Now**) |
| **Order detail** | `/orders/:id` | Follow one order | Back + number + date → **step tracker** (dots + connecting line) or red cancelled banner → Items → Delivery address → **Track Order** and **Cancel Order** (only while `PLACED`) | Skeleton block, "Order not found" |
| **Track order** | `/orders/:id/track` | Live map | Header + live status line → full-width Leaflet map (🏠 you, 🏍️ rider) → **OTP card** (when `PICKED_UP`: "Show this code to the rider at delivery") → waiting card when rider assigned but no GPS yet | No loading or error state |
| **Profile** | `/profile` | Account | Avatar (initial), name, phone/email → list: My Orders, Saved Addresses, Settings, Help & Support → **Sign Out** → bottom nav | Three rows are "coming soon" toasts |

### 5.3 Customer components

| Component | File | Notes |
|---|---|---|
| `BottomNav({ active })` | `components/BottomNav.tsx` | `active: 'home' \| 'menu' \| 'orders' \| 'profile'`; maps an `items` array to `.bottom-nav-item` buttons; emoji at 22px ✅ |
| `MenuItemCard` | inside `HomeScreen.tsx` | Image-or-emoji tile, name, compact price, round **+** (stops click propagation) |
| `CategoryChip` | inside `HomeScreen.tsx` | Icon + label button |
| `OrderCard` | inside `OrdersScreen.tsx` | Adds `cardActive` style for active orders |

All four are private to their screen file, so none is reusable today.

---

## 6. Rider app — screen by screen

### 6.1 Navigation map ✅

```
/login ──► /  Dashboard ──► /order/:id  (OrderAssigned)
              │  ▲                │
              │  └── auto-redirect when an active order exists
              ├──► /earnings   (placeholder)
              └──► /profile    (settings/help are "coming soon")
```

How the Dashboard links to `/earnings` and `/profile` is in the truncated part of `DashboardScreen` ❓. No rider tab bar component exists in the index.

### 6.2 Screens

| Screen | Route | Purpose | Layout and behaviour |
|---|---|---|---|
| **Login** | `/login` | Rider sign in | Hero (🏍️, "Rider Portal", "FastFood Delivery Partner") → card form. **Rejects non-rider accounts** with a toast. Shows an error for identifier only, not password |
| **Dashboard** | `/` | Go online, receive jobs | Header ("Hi, {first name} 🏍️", "Rider Dashboard", **Sign Out**) → **online card** with status dot (`dotOnline` / `dotOffline`) and toggle → incoming **delivery request** with **30 s countdown**, accept / decline → auto-navigates to the active order. Polls active order every 10 s |
| **Order assigned** | `/order/:id` | Run one delivery | Header (number, status) → **map** (🏪 pickup, 🏠 drop) → info card (starts with "🏠 Drop Address"; rest ❓). Handlers exist for **picked up**, **delivered** (requires OTP + cash collected in Rs.) and **delivery failed** (note "Customer unavailable"); the button labels and their placement are in the truncated part of the file ❓. Streams GPS to the order room, throttled to once per 4 s |
| **Earnings** | `/earnings` | History | Placeholder: 💰 "Earnings history will show here after your first delivery" |
| **Profile** | `/profile` | Account | Avatar initial, name, phone, Settings and Help ("coming soon"), **Sign Out** |

### 6.3 Delivery-request interaction ✅

1. Socket event `DELIVERY_REQUEST` arrives → sets pending request, resets timer to 30, shows toast "🛵 New delivery request!".
2. Interval counts down every second; at 0 the request is silently cleared (auto-decline).
3. `DELIVERY_REQUEST_CANCELLED` clears the request and shows "Order was cancelled".
4. **Accept** → `POST /orders/:id/accept` → invalidates active-order query → navigates to `/order/:id`. On failure: toast and request cleared.

---

## 7. Admin app — page by page

### 7.1 Shell ✅

```
┌────────────┬──────────────────────────────────────────────┐
│ 🍔 FastFood│  📊 Dashboard (page title from route)   (A) Name│  ← admin-header
│ Admin Panel├──────────────────────────────────────────────┤
│            │                                              │
│ 📊 Dashboard                                              │
│ 🧾 Orders  │              admin-content                   │
│ 🍔 Menu    │                                              │
│ 🏍️ Riders  │                                              │
│ 👥 Customers                                              │
│ 📈 Analytics                                              │
│            │                                              │
│ 🚪 Sign Out│                                              │
└────────────┴──────────────────────────────────────────────┘
```

- `AdminLayout` also opens a Socket.IO connection. On `order:new` it shows an orange toast ("🔔 New order #… — Rs. …", 6 s) and refreshes the orders and dashboard queries.
- Login only admits roles `admin` and `staff`.

### 7.2 Pages

| Page | Route | Contents |
|---|---|---|
| **Login** | `/login` | Centered 400 px card on `--bg`; 🍔 64 px; title in `--primary`; identifier + password; full-width **Sign In**. ⚠️ Also prints the default admin phone and password (D1) |
| **Dashboard** | `/` | **4 stat cards** (Today's Revenue, Active Orders, Today's Orders, Online Riders) → `grid-2`: **7-day revenue area chart** + **"🔴 Live Orders"** feed (top 5) → **Recent Orders** table (8 rows). Polls every 15 s |
| **Orders** | `/orders` | Title + search by order number → **status filter pills** (All with count + 9 statuses) → table: Order #, Customer, Items (first 2 + "+n more"), Total, Payment, Status badge, Placed, **Actions**. Action buttons are generated from a `TRANSITIONS` map; reject/cancel are red, the rest green. Polls every 10 s |
| **Menu manager** | `/menu` | Segmented tabs **🍔 Items / 📂 Categories** + **+ Add Item** → Items table (emoji, name, description, category, price, 🟢/🔴 availability toggle, **✏️ Edit**, **🗑️**) or categories card grid. Create/edit form and image upload (`/uploads/image`) |
| **Riders** | `/riders` | Online/Total mini-cards → table: avatar, name (+ SUSPENDED tag), phone, online badge, deliveries, **unsettled cash** (amber when > 0), **💰 Settle** and **🚫 Suspend / ✅ Restore**. Polls every 15 s |
| **Customers** | `/customers` | Search by name or phone → "n customers found" → table: avatar (info colour), name, phone, email, joined, status badge, suspend/restore with confirm |
| **Analytics** | `/analytics` | 4 KPI cards (Total Revenue, Avg Order Value, Total Orders, Cancellation Rate) → 30-day revenue area chart → `grid-2`: **status donut** + **orders-by-hour bar chart** → top-selling items (8) |

### 7.3 Charts ✅

All Recharts, all dark-styled with hard-coded hex values:

| Property | Value |
|---|---|
| Series colour | `#f97316`, gradient fill from 30–40 % opacity to 0 |
| Grid | `#374151`, dashed `3 3` |
| Axis ticks | `#9ca3af`, 9–12 px, no axis line, no tick line |
| Tooltip | background `#1f2937`, border `1px solid #374151`, radius 8, text `#f9fafb` |
| Heights | 200 (dashboard), 240 (30-day), 220 (donut and bar) |
| Donut | inner 55, outer 85, padding angle 3, round legend icons |

---

## 8. Cross-app patterns

| Pattern | How it is done | Consistent? |
|---|---|---|
| **Buttons** | Customer/rider `btn-primary` (full width). Admin `btn` + `btn-primary/ghost/success/danger` + `btn-sm` | ❌ different contracts |
| **Forms** | Label + `input` + red `error-text`; validation via react-hook-form (customer, rider) or raw `useState` (admin) | 🟡 partly |
| **Cards** | `styles.card` in modules (customer/rider); global `.card` in admin | ❌ |
| **Status chips** | Customer `status-badge status-<slug>`; admin `badge badge-<slug>` | ❌ same idea, two class sets |
| **Avatars** | Initial in a circle: profile (customer, rider), table rows and header (admin) | ✅ |
| **Back navigation** | Text `←` button at top-left, `navigate(-1)` or an explicit path | ✅ |
| **Money** | Always `formatMoneyCompact(paisa)` → `Rs. 1,250` (no decimals) | ✅ |
| **Toasts** | `toast.success / error / ()` after every mutation | ✅ |
| **Empty states** | Emoji + sentence (+ button on customer) | 🟡 |
| **Loading** | `.skeleton` blocks (customer); "Loading…" text (admin tables, rider) | ❌ |
| **Error states for failed queries** | None found; only `isLoading` is read | ❌ |
| **Destructive confirmation** | Native `confirm()` / `prompt()` | ❌ unstyled |

---

## 9. Order status → UI mapping

Statuses come from the shared enum ✅. `STATUS_LABEL` and `ACTIVE_STATUSES` are copied from customer `OrdersScreen.tsx` ✅.

| Enum value | Customer label | "Active" (live card + Track button) | Customer detail screen | Admin filter tab |
|---|---|---|---|---|
| `PLACED` | Order Placed | ✅ | Tracker step 1 (📋) | ✅ |
| `ACCEPTED` | Accepted | ✅ | Tracker | ✅ |
| `PREPARING` | Preparing | ✅ | Tracker | ✅ |
| `READY` | Ready | ✅ | Tracker | ✅ |
| `RIDER_ASSIGNED` | Rider Assigned | ✅ | Tracker; track screen shows "🔔 Rider heading to restaurant" | ✅ |
| `PICKED_UP` | On the way | ✅ | Tracker; track screen shows "🏍️ Rider on the way!" and the **OTP** | ✅ |
| `DELIVERED` | Delivered | — | Tracker complete; track screen shows "🎉 Delivered!" | ✅ |
| `CANCELLED` | Cancelled | — | Red banner (+ reason) | ✅ |
| `REJECTED` | Rejected | — | Red banner | ✅ |
| `DELIVERY_FAILED` | Delivery Failed | — | Red banner | ❌ **missing** (D10) |

Only the first tracker step is visible in the index (`PLACED / Order Placed / 📋`); the remaining step labels and icons are ❓.

**Admin action buttons** (labels ✅, which status offers which action ❓ — it lives in the `TRANSITIONS` map):

| Target status | Button |
|---|---|
| `ACCEPTED` | ✅ Accept (green) |
| `REJECTED` | ❌ Reject (red) |
| `PREPARING` | 👨‍🍳 Prepare |
| `READY` | 📦 Ready |
| `RIDER_ASSIGNED` | 🏍️ Assign |
| `CANCELLED` | red variant |

Badge colours per status ❓ (CSS not readable).

---

## 10. Realtime and refresh behaviour

| Where | Mechanism | Interval / event |
|---|---|---|
| Customer Orders list | Polling | 10 s |
| Customer Order detail | Polling | 8 s |
| Customer Track | Polling + socket | 15 s; `join:order`, `RIDER_LOCATION_UPDATE` |
| Customer OTP | Query | Enabled only when status is `PICKED_UP` |
| Rider active order (Dashboard) | Polling | 10 s |
| Rider Order assigned | Polling + GPS stream | 10 s; location emit throttled to 4 s |
| Rider requests | Socket | `DELIVERY_REQUEST`, `DELIVERY_REQUEST_CANCELLED` |
| Admin Orders | Polling | 10 s |
| Admin Dashboard / Riders | Polling | 15 s |
| Admin new orders | Socket | `order:new` → toast + query invalidation |
| Customer app resume | Capacitor `appStateChange` | Reconnect socket + refetch active order |
| Customer network return | Capacitor `networkStatusChange` | Reconnect socket |

Design consequence: the UI has **no "live" indicator, no stale-data cue, and no offline banner**, so a user cannot tell whether the data on screen is current.

---

## 11. Native (Capacitor) design layer

Installed in customer and rider ✅: `status-bar`, `splash-screen`, `haptics`, `geolocation`, `network`, `browser`, `app`.

| Capability | Evidence of use |
|---|---|
| App resume and network reconnect | ✅ customer `lib/lifecycle.ts` |
| Rider GPS | ✅ rider uses `navigator.geolocation.watchPosition` (web API, not the Capacitor plugin) |
| Status-bar colour, splash config, haptics, back-button handling, safe-area insets | ❓ not found in the code read |
| App ID, display name, launcher icon, splash artwork | ❓ in `capacitor.config.*` and `android/` resources |

---

## 12. Copy and voice

Strings observed ✅:

- **Greetings:** "Hello, {name} 👋", "What are you craving today?", "Hi, {name} 🏍️".
- **Actions:** Sign In, Create Account, Proceed to Checkout, Order Now, Track Order, Cancel Order, Sign Out, Accept, Reject, Prepare, Ready, Assign, Settle, Suspend, Restore.
- **Errors fall back to** "Login failed", "Registration failed", "Failed to place order", "Failed", "Could not accept order", "Upload failed".
- **Placeholders:** `+92300xxxxxxx or you@email.com`, `House #, Street, Area, City`, `Near mosque, school, etc.`.
- **Casing:** Title Case on buttons ("Proceed to Checkout"), sentence case elsewhere.

Wording gaps seen in the code: the button says "Sign In" but the failure toast says "Login failed"; the same destructive idea is called "Clear" (cart), "Delete" (menu) and "Suspend" (users); several mutation errors fall back to the bare word "Failed"; and "Sign Out" is the label while the style classes are called `logoutBtn` / `logout`. An action should keep one name through its whole flow (button, confirmation, toast).

---

## 13. Accessibility audit (code-level)

| Check | Result |
|---|---|
| Icon-only controls have accessible names (`🛒`, `+`, `←`, `✕`, `🗑️`) | ❌ none have `aria-label` |
| Emoji marked decorative (`aria-hidden`) | ❌ no |
| Form labels linked to inputs (`htmlFor` / `id`) | ❌ labels are siblings, not linked |
| Errors announced (`role="alert"`, `aria-describedby`) | ❌ |
| Colour contrast: white text on `#f97316` | ❌ **≈ 2.8 : 1** (AA needs 4.5 : 1). Verified on the admin toast (white, weight 700, `rgba(249,115,22,0.9)`); likely also on primary buttons ❓ |
| Colour contrast: `#9ca3af` on `#1f2937` (admin muted text) | ✅ ≈ 5.8 : 1 |
| Colour contrast: `#f97316` text on `#1f2937` | ✅ ≈ 5.2 : 1 |
| Keyboard operation of clickable `div`s (profile rows, order cards, nav) | ❌ `onClick` on non-interactive elements, no `role`/`tabIndex` |
| Visible focus style | ❓ |
| Reduced-motion handling for skeleton | ❓ |
| Tap-target size (44 × 44 px) | ❓ (add buttons and quantity steppers are likely small) |
| Language and RTL (Urdu) | ❌ English-only strings in code; no i18n or RTL handling seen |

---

## 14. Design issues found

Severity: **H** = fix before real users, **M** = fix soon, **L** = polish.

| ID | Sev | App | Finding | Where |
|---|---|---|---|---|
| D1 | H | Admin | Login screen prints default credentials in plain text | `LoginPage.tsx` |
| D2 | H | Customer | Delivery pin defaults to the **restaurant's coordinates** (`31.5204`, `74.3587`) and is shown as raw latitude/longitude inputs under the hint "Coordinates auto-filled". Nothing fills them from the device even though `@capacitor/geolocation` is installed. A customer who doesn't edit them sends the rider to the restaurant | `CheckoutScreen.tsx` |
| D3 | M | Customer | **Totals disagree.** Cart adds a Rs. 100 delivery fee under Rs. 1,000; Checkout's "Total (est.)" omits delivery entirely | `CartScreen.tsx`, `CheckoutScreen.tsx` |
| D4 | M | Customer | Cart line key is `menuItemId:sizeLabel`. Two lines of the same item and size with **different add-ons collide**, and quantity updates target that key | `CartScreen.tsx` |
| D5 | M | All | Orange `#f97316` with white text fails contrast (≈ 2.8 : 1) | Admin toast; probably buttons |
| D6 | M | All | Emoji are the only icon system: no accessible names, differ between Android versions and OEMs, cannot follow tokens for size or colour | everywhere |
| D7 | M | All | Native `confirm()` / `prompt()` for destructive actions (clear cart, **cancel order — collects the reason with `prompt`**, delete menu item, suspend customer) | Cart, OrderDetail, Menu, Customers |
| D8 | M | Admin | Heavy inline styling (login page, filter pills, segmented tabs, avatars) even though global classes exist; `fontFamily: 'Inter, sans-serif'` repeated by hand | `LoginPage`, `OrdersPage`, `MenuPage`, `RidersPage`, `CustomersPage` |
| D9 | M | All | No shared design tokens or components. `btn-primary` has two contracts; rider uses module `styles.label` where customer uses global `.label` | repo-wide |
| D10 | M | All | Status knowledge is copy-pasted (`STATUS_LABEL`, `STATUS_STEPS`, `ACTIVE_STATUSES`, admin `STATUSES`/`TRANSITIONS`, ternaries on Track screen, cancelled lists in Dashboard/Analytics). Admin filter tabs **omit `DELIVERY_FAILED`** | multiple |
| D11 | M | Customer, Admin | Badge slug built with `.replace('_', '-')` (first underscore only) in some places and `/_/g` in others. Works today only because no status has two underscores | `OrdersScreen`, `DashboardPage`, `OrdersPage` |
| D12 | M | Rider | `isOnline` starts as `false` and no sync with the server is visible in the code read; after a reload the toggle can contradict the server | `DashboardScreen.tsx` |
| D13 | L | Rider | A new delivery request overwrites `timerRef` without clearing the previous interval, so overlapping requests can run two countdowns | `DashboardScreen.tsx` |
| D14 | M | Customer, Rider | Dead-end rows: Saved Addresses, Settings, Help show "coming soon" toasts; Rider Earnings is an empty placeholder | `ProfileScreen`, `EarningsScreen` |
| D15 | L | Customer | Home promos are hard-coded ("Up to 30% off", "Burgers from Rs. 350") and "Popular" is simply the first 12 menu items | `HomeScreen.tsx` |
| D16 | L | All | Loading UI inconsistent: skeletons in customer, plain "Loading…" text in admin tables and rider | multiple |
| D17 | L | All | No query-error UI anywhere; a failed request looks like an empty list | multiple |
| D18 | L | Customer | Order detail shows a generic `🍽️`/`🍔` per line instead of the item's own emoji or image | `OrderDetailScreen.tsx` |
| D19 | M | Admin | Analytics reads `it.totalPaisa` for per-item revenue, while the customer screen reads `item.lineTotalPaisa`. One of them is probably wrong, which would show Rs. 0 revenue for top items. **Verify against the order-item schema** | `AnalyticsPage.tsx`, `OrderDetailScreen.tsx` |
| D20 | L | Admin | Page titles are defined twice (nested ternary in `AdminLayout` and `NAV` in `Sidebar`) | `App.tsx`, `Sidebar.tsx` |
| D21 | L | Admin | No responsive behaviour is visible for the fixed sidebar layout ❓ | `admin-layout` CSS |
| D22 | L | Admin | Chart colours are hex literals, so they cannot follow tokens or a future light theme | Dashboard, Analytics |
| D23 | L | Rider | Cash-collected field starts empty (COD amount not pre-filled); Rs → paisa conversion is hand-rolled with `parseFloat * 100` instead of a shared helper | `OrderAssignedScreen.tsx` |
| D24 | L | Customer, Rider | Public OpenStreetMap tile servers are used directly; fine for an MVP, but heavy use is against OSM's tile policy | Track, OrderAssigned |

---

## 15. Missing screens and states

| Gap | Why it matters |
|---|---|
| Address book and map pin picker | Fixes D2 and the "Saved Addresses" dead end |
| Order-placed confirmation / receipt | Checkout jumps straight to Order detail |
| Rating and feedback after delivery | Closes the loop for a food product |
| Rider navigation hand-off (open Google Maps) | `@capacitor/browser` is installed but unused for this |
| Rider earnings and cash-to-settle summary | Placeholder today; also blocked by the unwired cash ledger in `HONEST_OVERVIEW.md` |
| Offline / reconnecting banner | Sockets and polling fail silently |
| Error boundary + 404 + "session expired" screens | Wildcard route just redirects to `/` |
| Admin: order detail drawer, rider assignment picker, settlement history, empty-state illustrations | Admin acts directly from table rows |
| Notification permission and push UI | `NotificationsService` exists on the API but no UI is visible |
| Settings (language, theme, logout everywhere) | All "coming soon" |

---

## 16. Design maturity scorecard (reviewer's assessment)

| Dimension | Score | Note |
|---|---|---|
| Visual identity | 6 / 10 | Clear orange + emoji personality; no real brand assets |
| Consistency across apps | 4 / 10 | Three stylesheets, different class contracts |
| Component reuse | 3 / 10 | Components live inside screen files |
| Accessibility | 3 / 10 | See §13 |
| State coverage (loading, empty, error, offline) | 4 / 10 | Loading and empty are decent on customer; error and offline are absent |
| Theming and tokens | 4 / 10 | CSS variables exist; hex literals leak into code |
| Responsiveness | ❓ | Cannot be judged without the CSS |
| Documentation | 1 / 10 before this file | |

---

## 17. What is still unverified, and how to verify it

| Unknown | Open this file |
|---|---|
| Exact values of `--bg`, `--surface`, `--primary`, semantic colours, radii, shadows | `apps/*/src/index.css` (or the global stylesheet imported by `main.tsx`) |
| Customer / rider font stack and base font size | same, plus `apps/*/index.html` |
| Status badge colours (`.status-*`, `.badge-*`) | same |
| Bottom-nav item labels and icons | `apps/customer/src/components/BottomNav.tsx` (top of file) |
| Tracker steps 2–end | `apps/customer/src/screens/OrderDetailScreen.tsx` (lines 7–15) |
| Admin `TRANSITIONS` map and Pie `COLORS` | `apps/admin/src/pages/OrdersPage.tsx`, `AnalyticsPage.tsx` |
| Rider Dashboard body (online card, request sheet, links to Earnings/Profile) | `apps/rider/src/screens/DashboardScreen.tsx` (second half) |
| Rider order-assigned body (cards, buttons) | `apps/rider/src/screens/OrderAssignedScreen.tsx` (second half) |
| Toast position and default styling | `apps/*/src/main.tsx` (`<Toaster />`) |
| `viewport-fit=cover`, theme-color, safe-area handling | `apps/*/index.html`, global CSS |
| App name, ID, splash and status-bar settings, icons | `apps/*/capacitor.config.*`, `apps/*/android/app/src/main/res` |
| Order-item field names (`lineTotalPaisa` vs `totalPaisa`) | `apps/api/src/modules/orders/*.schema.ts` |

---

## Appendix A — Route tables

**Customer** ✅

| Path | Screen | Guard |
|---|---|---|
| `/login` | LoginScreen | Public |
| `/signup` | SignupScreen | Public |
| `/` | HomeScreen | Private |
| `/menu` | MenuScreen | Private |
| `/menu/:id` | ProductDetailScreen | Private |
| `/search` | SearchScreen | Private |
| `/cart` | CartScreen | Private |
| `/checkout` | CheckoutScreen | Private |
| `/orders` | OrdersScreen | Private |
| `/orders/:id` | OrderDetailScreen | Private |
| `/orders/:id/track` | TrackOrderScreen | Private |
| `/profile` | ProfileScreen | Private |
| `*` | Redirect to `/` | — |

**Rider** ✅

| Path | Screen | Guard |
|---|---|---|
| `/login` | LoginScreen | Public |
| `/` | DashboardScreen | Private |
| `/order/:id` | OrderAssignedScreen | Private |
| `/earnings` | EarningsScreen | Private |
| `/profile` | ProfileScreen | Private |
| `*` | Redirect to `/` | — |

**Admin** ✅

| Path | Page | Guard |
|---|---|---|
| `/login` | LoginPage | Redirects to `/` when authenticated |
| `/` | DashboardPage | Private + AdminLayout |
| `/orders` | OrdersPage | Private + AdminLayout |
| `/menu` | MenuPage | Private + AdminLayout |
| `/riders` | RidersPage | Private + AdminLayout |
| `/customers` | CustomersPage | Private + AdminLayout |
| `/analytics` | AnalyticsPage | Private + AdminLayout |
| `*` | Redirect to `/` | — |

## Appendix B — File index for designers

```
apps/customer/src/
  App.tsx                       routes, PrivateRoute, PublicRoute
  components/BottomNav.tsx      the only shared customer component
  screens/*.tsx + *.module.css  12 screens, one CSS module each
  lib/lifecycle.ts              resume + network handling
apps/rider/src/
  App.tsx
  screens/*.tsx + *.module.css  5 screens
apps/admin/src/
  App.tsx                       routes + AdminLayout (header, socket toast)
  components/Sidebar.tsx        NAV array + sidebar
  pages/*.tsx                   7 pages, global classes + inline styles
packages/utils/src/money.ts     formatMoney, formatMoneyCompact
packages/utils/src/date.ts      formatDate, formatDateTime
packages/shared-types/src/enums.ts   OrderStatus, PaymentStatus, Role
```
